package ro.fmi.tema1;
import java.sql.*;

class Main {
    public static void main(String args[]) {
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");

            Connection con = DriverManager.getConnection(
                    "jdbc:oracle:thin:@localhost:1521:xe", "c##ana", "parola");

            if(con == null) {
                System.out.println("Nu s-a facut conexiunea");
            }

            Statement stmt_select = con.createStatement();
            Statement stmt_update = con.createStatement();

            ResultSet rs = stmt_select.executeQuery("select * from clasific_clienti");

            while (rs.next()){
                int id_client = rs.getInt(1);
                int id_categorie = rs.getInt(2);
                int nr_produse = rs.getInt(3);
                String clasificare = rs.getString(4);
                String afisare = "Clientul cu id-ul " + id_client + " are id-ul categoriei " + id_categorie + " si clasificarea " + clasificare + " si va primi id-ul categoriei ";
                if(nr_produse <= 40){
                    stmt_update.execute("update clasific_clienti set clasificare='A', id_categorie=" + (id_categorie + 1) + " where id_client = " + id_client );
                    afisare += (id_categorie + 1) + " si clasificarea A";
                } else if(nr_produse <= 60){
                    stmt_update.execute("update clasific_clienti set clasificare='B', id_categorie=" + (id_categorie + 2) + " where id_client = " + id_client );
                    afisare += (id_categorie + 2) + " si clasificarea B";
                } else if(nr_produse <= 80){
                    stmt_update.execute("update clasific_clienti set clasificare='C', id_categorie=" + (id_categorie + 3) + " where id_client = " + id_client );
                    afisare += (id_categorie + 3) + " si clasificarea C";
                } else {
                    stmt_update.execute("update clasific_clienti set clasificare='D', id_categorie=" + (id_categorie + 4) + " where id_client = " + id_client );
                    afisare += (id_categorie + 4) + " si clasificarea D";
                }
                System.out.println(afisare);
            }
            stmt_select.close();
            stmt_update.close();
            con.close();
        } catch (Exception e) {
            System.out.println(e);
        }

    }
}