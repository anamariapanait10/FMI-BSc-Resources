/*
 * @(#)PackageT.java
 */

package javax.ide.model.java.source.tree;

/**
 * A package declaration. <p/>
 *
 * @author Andy Yu
 * */
public interface PackageT
  extends Tree, HasNameT, HasModifiersT
{
  // ----------------------------------------------------------------------

  /**
   * Gets the javadoc comment symbol.
   *
   * @return The DocCommentT associated with this symbol.
   */
  public DocCommentT getDocComment();

  /**
   * Attempts to set the javadoc comment symbol.
   *
   * @param comment The new comment element.
   */
  public void setDocComment( DocCommentT comment );


}
