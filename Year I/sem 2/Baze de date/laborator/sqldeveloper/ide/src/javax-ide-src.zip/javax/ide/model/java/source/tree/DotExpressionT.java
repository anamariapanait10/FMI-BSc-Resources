/*
 * @(#)DotExpressionT.java
 */

package javax.ide.model.java.source.tree;

/**
 * A expression representing an identifier selector. <p/>
 *
 * @author Andy Yu
 * */
public interface DotExpressionT
  extends DereferenceExpressionT, HasNameT
{
}
