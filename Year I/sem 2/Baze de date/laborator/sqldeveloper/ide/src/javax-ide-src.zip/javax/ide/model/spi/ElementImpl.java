/*
 * Copyright 2005 by Oracle USA
 * 500 Oracle Parkway, Redwood Shores, California, 94065, U.S.A.
 * All rights reserved.
 */
package javax.ide.model.spi;

/**
 * The bridge for an Element.
 */
public interface ElementImpl 
{
  public String getLabel();
  
  public String getToolTip();
  
  public String getLongLabel();
  
  public Object getIcon();
}
