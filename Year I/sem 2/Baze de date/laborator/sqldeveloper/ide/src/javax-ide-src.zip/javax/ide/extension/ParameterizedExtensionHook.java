package javax.ide.extension;

import java.util.Map;

/**
 * An experimental way for hook handlers to accept parameters from 
 * the hook-handler definiton
 */
public abstract class ParameterizedExtensionHook extends ExtensionHook
{
  public abstract void setHookHandlerParameters(Map<String,String> parameterMap);
}
